﻿using System;
using System.Collections.Generic;

namespace OasisWebApplication.Models
{
    public partial class TableDetails
    {
     

        public string TableId { get; set; }
        public int Accommodation { get; set; }
        public string Type { get; set; }
        public string TableInchargeId { get; set; }

     
    }
}
