﻿using System;
using System.Collections.Generic;

namespace OasisWebApplication.Models
{
    public partial class CustodianDetails

    {

        public string CustodianId { get; set; }
        public string CustodianName { get; set; }
        public int? Experience { get; set; }
        public int? FeedbackCount { get; set; }

       
    }
}
