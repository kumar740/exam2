﻿using System;
using System.Collections.Generic;

namespace OasisDataAccessLayer.Models
{
    public partial class CustodianDetail
    {
        public CustodianDetail()
        {
            TableDetail = new HashSet<TableDetail>();
        }

        public string CustodianId { get; set; }
        public string CustodianName { get; set; }
        public int? Experience { get; set; }
        public int? FeedbackCount { get; set; }

        public ICollection<TableDetail> TableDetail { get; set; }
    }
}
