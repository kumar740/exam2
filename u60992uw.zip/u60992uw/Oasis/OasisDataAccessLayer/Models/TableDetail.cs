﻿using System;
using System.Collections.Generic;

namespace OasisDataAccessLayer.Models
{
    public partial class TableDetail
    {
        public TableDetail()
        {
            CustomerDetail = new HashSet<CustomerDetail>();
        }

        public string TableId { get; set; }
        public int Accommodation { get; set; }
        public string Type { get; set; }
        public string TableInchargeId { get; set; }

        public CustodianDetail TableIncharge { get; set; }
        public ICollection<CustomerDetail> CustomerDetail { get; set; }
    }
}
