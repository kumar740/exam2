﻿using System;
using System.Collections.Generic;

namespace OasisDataAccessLayer.Models
{
    public partial class CustomerDetail
    {
        public long BookingId { get; set; }
        public DateTime? BookingDate { get; set; }
        public string TableNumber { get; set; }
        public string CustomerName { get; set; }
        public long? Contact { get; set; }
        public int? Duration { get; set; }
        public int? TotalSeats { get; set; }

        public TableDetail TableNumberNavigation { get; set; }
    }
}
