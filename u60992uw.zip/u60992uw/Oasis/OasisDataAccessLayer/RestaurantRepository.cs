﻿using OasisDataAccessLayer.Models;
using System;
using System.Linq;
using System.Collections.Generic;

namespace OasisDataAccessLayer
{
    public class RestaurantRepository
    {
        RestaurantDBContext context;
        public RestaurantDBContext Context { get { return context; } }


        public RestaurantRepository()
        {
            context = new RestaurantDBContext();
        }
        public RestaurantRepository(RestaurantDBContext restaurantContext)
        {
            context = new RestaurantDBContext();
        }

        public List<TableDetail> ShowTableDetails()
        {
            List<TableDetail> TObj = new List<TableDetail>();
            try
            {
                TObj = (from r in Context.TableDetail

                        select r).ToList();
            }
            catch (Exception)
            {
                TObj = null;
            }
            return TObj;

        }
        public List<CustomerDetail> GetCustomerDetails()
        {
            List<CustomerDetail> CObj = new List<CustomerDetail>();
            try
            {
                CObj = (from r in Context.CustomerDetail

                        select r).ToList();
            }
            catch (Exception)
            {
                CObj = null;
            }
            return CObj;
        }
        public bool AddTable(TableDetail TableObj)
        {
            try
            {
                Context.TableDetail.Add(TableObj);
                Context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        public bool RemoveCustomerDetails(int BookingId)
        {
            try
            {
                CustomerDetail e = (from e1 in context.CustomerDetail
                                    where e1.BookingId == BookingId
                                    select e1).First();
                context.Remove(e);
                context.SaveChanges();
                return true;
            }
            catch (Exception)
            {
                return false;
            }

        }
        public bool UpdateInchargeId(TableDetail TObj)
        {
            try
            {
                TableDetail T = (from e1 in context.TableDetail


                                 where e1.TableId == TObj.TableId

                                 select e1).First();
                T.TableInchargeId = TObj.TableInchargeId;


                context.SaveChanges();
                return true;

            }
            catch (Exception)
            {
                return false;
            }

        }


    }
}
