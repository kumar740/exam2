import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { routing } from './app.routing';
import { AppComponent } from './app.component';
import { GetTableDetailsComponent } from './components/get-table-details/get-table-details.component';
import { RestaurantService }from './services/restaurant.service';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AddTableComponent } from './components/add-table/add-table.component';
import { UpdateTableInchargeIdComponent } from './components/update-table-incharge-id/update-table-incharge-id.component';
import { GetCustomerDetailsComponent } from './components/get-customer-details/get-customer-details.component';
import { HeaderComponent } from './components/header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    GetTableDetailsComponent,
    AddTableComponent,
    UpdateTableInchargeIdComponent,
    GetCustomerDetailsComponent,
    HeaderComponent

  ],
  imports: [
    BrowserModule,
    routing,
    FormsModule,
    HttpClientModule,
  ],
  providers: [RestaurantService],
  bootstrap: [AppComponent]
})
export class AppModule { }
