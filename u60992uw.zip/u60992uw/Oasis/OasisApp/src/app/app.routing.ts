import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { GetTableDetailsComponent } from './components/get-table-details/get-table-details.component';
import { AddTableComponent } from './components/add-table/add-table.component';
import { UpdateTableInchargeIdComponent } from './components/update-table-incharge-id/update-table-incharge-id.component';
import { GetCustomerDetailsComponent } from './components/get-customer-details/get-customer-details.component';


const routes: Routes = [
  { path: '', component: GetTableDetailsComponent },
  { path: 'viewTableDetails', component: GetTableDetailsComponent },
  { path: 'viewCustomer', component: GetCustomerDetailsComponent },
  { path: 'addTable', component: AddTableComponent },
  { path: 'updatetableInchargeId/:tableId/:type/:accommodation/:tableInchargeId', component: UpdateTableInchargeIdComponent }
];

export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
