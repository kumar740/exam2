import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { ITableDetails } from '../interfaces/TableDetails';
import { ICustodian } from '../interfaces/CustodianDetails';
import { ICustomer } from '../interfaces/Customer';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  custodianId: string
  constructor(private _http: HttpClient) { }

  getTableDetails(): Observable<ITableDetails[]> {
    //To do implement necessary logic
    return null;
  }

  getCustomerDetails(): Observable<ICustomer[]> {
    //To do implement necessary logic
    return null;
  }

  addTableDetails(tableId: string, type: string, accommodation: number, tableInchargeId: string): Observable<boolean> {
    //To do implement necessary logic
    return null;
  }
  updateTableIncharge(tableId: string, type: string, accommodation: number, tableInchargeId: string): Observable<boolean> {
    //To do implement necessary logic
    return null;
  }

  removeCustomer(bookingId: number, customerName: string, bookingdate: Date, contact: number, tableNumber: string, duration: number, totalSeats: number): Observable<boolean> {
    //To do implement necessary logic
    return null;
  }

  errorHandler(error: HttpErrorResponse) {
    //To do implement necessary logic
    return null;
  }
}
