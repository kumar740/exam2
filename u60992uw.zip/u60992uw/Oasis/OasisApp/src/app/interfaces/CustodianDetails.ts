export interface ICustodian {
  custodianName: string;
  custodianId: string;
  experience: number;
  feedbackcount: number;
}
