import { Component, OnInit } from '@angular/core';
import { RestaurantService } from '../../services/restaurant.service';
import { ICustomer } from '../../interfaces/Customer';
import { Data } from '@angular/router';

@Component({
  selector: 'app-get-customer-details',
  templateUrl: './get-customer-details.component.html',
  styleUrls: ['./get-customer-details.component.css']
})
export class GetCustomerDetailsComponent implements OnInit {
  customerDetails: ICustomer[];
  errorMsg: string;
  showMsgDiv: boolean = false;
  status: boolean;
  constructor(private restaurantservice: RestaurantService) { }

  ngOnInit() {
       //To do implement necessary logic
  }
  getCustomer() {
       //To do implement necessary logic
  }

  deleteCustomer(bookingId: number, bookingdate: Date, customerName: string, contact: number, tableNumber: string, duration: number, totalSeats: number) {
       //To do implement necessary logic
  }

}
