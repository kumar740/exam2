import { Component, OnInit, ViewChild } from '@angular/core';
import {NgForm} from '@angular/forms';
import { RestaurantService } from '../../services/restaurant.service'
import { HttpClient } from '@angular/common/http';
import { ITableDetails } from '../../interfaces/TableDetails'
import { ActivatedRoute } from '@angular/router';
import { createWiresService } from 'selenium-webdriver/firefox';

@Component({
  selector: 'app-update-table-incharge-id',
  templateUrl: './update-table-incharge-id.component.html',
  styleUrls: ['./update-table-incharge-id.component.css']
})
export class UpdateTableInchargeIdComponent implements OnInit {
  @ViewChild(NgForm) ngForm: NgForm;
  tableId: string;
  type: string;
  accommodation: number;
  tableInchargeId: string;
  errorMsg: string;
  showMsgDiv: boolean = false;
  status: boolean;
  tableDetails: ITableDetails
  constructor(private restaurantservice: RestaurantService, private route: ActivatedRoute) { }

  ngOnInit() {
    //To do implement necessary logic
  }
  updateTableInchargeId(tableInchargeId: string)
  {
        //To do implement necessary logic    
  }  

}
