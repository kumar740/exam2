export * from './add-table/add-table.component';
export * from './get-customer-details/get-customer-details.component';
export * from './get-table-details/get-table-details.component';
export * from './header/header.component';
export * from './update-table-incharge-id/update-table-incharge-id.component';
